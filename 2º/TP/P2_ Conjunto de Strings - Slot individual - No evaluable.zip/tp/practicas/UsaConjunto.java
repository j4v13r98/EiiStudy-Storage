package tp.practicas;
import tp.practicas.ConjuntoDeStrings;

public class UsaConjunto{
    public static void main(String[] args){
        String[] v1 = {"cero"};
        String[] v2 = {"cero"};
        String[] v3 = {"a", "b", "c", "a", "w"};
        String[] v4 = {};
        String[] v5 = {"a", "w"};
        
        ConjuntoDeStrings c1 = new ConjuntoDeStrings(v1);
        ConjuntoDeStrings c2 = new ConjuntoDeStrings(v2);
        ConjuntoDeStrings c3 = new ConjuntoDeStrings(v3);
        ConjuntoDeStrings c4 = new ConjuntoDeStrings(v4);
        ConjuntoDeStrings c5 = new ConjuntoDeStrings(v5);

        System.out.println(c1.cardinal());
        System.out.println(c1.equals(c2));
        System.out.println(c1.equals(c3));
        System.out.println(c1.estáVacío());
        System.out.println(c4.estáVacío());
        System.out.println(c1.contenido(c2));
        System.out.println(c2.contenido(c3));
        System.out.println(c5.contenido(c4));
        System.out.println(c3.contenido(c5));
        System.out.println(c5.contenido(c3));
        System.out.println(c3.unión(c5).toString());
        System.out.println(c3.intersección(c5));
        System.out.println(c5.intersección(c3));
        System.out.println(c3.diferencia(c5));
        System.out.println(c3.elementos().toString());
    }
}