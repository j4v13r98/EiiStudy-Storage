package tp.practicas;
import java.lang.Object;
import java.util.Arrays;

public class ConjuntoDeStrings{
    private String[] set = new String[0]; 
    
    public ConjuntoDeStrings(String... arg){
        for (String element:arg){
            añade(element);
        }
    }
    
    public int cardinal(){
        return set.length;
    }
    
    public boolean estáVacío(){
        if (set.length == 0){
            return true;
        }else{
            return false;
        }
    }
    
    public boolean contenido(ConjuntoDeStrings obj){
        if (obj.cardinal() > this.cardinal()){
            return false;
        }
        for (String element:obj.set){
            if (!this.pertenece(element)){
                return false;
            }
        }
        return true;
    }
    
    // set-> [a, b, t, h] para meter p...
    public boolean añade(String element){
        if(pertenece(element)){
            return false;
        }
        //set-> [a, b, t, h] length 4
        set = Arrays.copyOf(set, set.length+1);
        //set -> [a, b, t, h, _] length 5
        //pos -> [0, 1, 2, 3, 4]
        set[set.length-1] = element;
        //set-> [a, b, t, h, p]
        return true;
    }
    
    public boolean pertenece(String element){
        if (element == null){
            return false;
        }
        for (String s:set){
            if(s.equals(element)){
                return true;
            }
        }
        return false;
    }
    
    @Override
    //Esta parte siempre es necesaria y apenas cambia
    public boolean equals(Object obj){
        if (this == obj){
            return true;
        }else if(!(obj instanceof ConjuntoDeStrings)){ //varía la clase
            return false;
        }

    //Aquí cambia más
        ConjuntoDeStrings other = (ConjuntoDeStrings)obj;
        if(this.cardinal() != other.cardinal()){
            return false;
        }
        for (String item:set){
            if (!(other.pertenece(item))){
                return false;
            }
        }
        return true;
    }
    
    public ConjuntoDeStrings unión(ConjuntoDeStrings other){
        String[] auxCopy = Arrays.copyOf(set, set.length + other.cardinal());
        int i=set.length;
        for (String element:other.set){
            auxCopy[i++] = element;
        }
        ConjuntoDeStrings result = new ConjuntoDeStrings(auxCopy);
        return result;
    }
    
    public ConjuntoDeStrings intersección(ConjuntoDeStrings other){
        int counter = 0;
        for (String element:other.set){
            if (this.pertenece(element)){
                counter += 1;
            }
        }
        String[] auxCopy = new String[counter];
        int i = 0;
        for (String element:other.set){
            if (this.pertenece(element)){
                auxCopy[i++] = element;
            }
        }
        ConjuntoDeStrings result = new ConjuntoDeStrings(auxCopy);
        return result;
    }
    
    public ConjuntoDeStrings diferencia(ConjuntoDeStrings other){
        int counter = 0;
        for (String element:other.set){
            if (this.pertenece(element)){
                counter += -1;
            }
        }
        String[] auxCopy = new String[cardinal() + counter];
        int i = 0;
        for (String element:set){
            if (!other.pertenece(element)){
                auxCopy[i++] = element;
            }
        }
        ConjuntoDeStrings result = new ConjuntoDeStrings(auxCopy);
        return result;
    }
    
    public String[] elementos(){
        String[] elements = Arrays.copyOf(set, cardinal());
        return elements;
    }
    
    //public String toString(){
        //String result = "";
        //for (String element:set){
            //result += element +", ";
        //}
        //return "[" + result + "]";
    //}
}