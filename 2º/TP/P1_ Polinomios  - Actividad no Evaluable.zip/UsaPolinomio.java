public class UsaPolinomio{
    public static void main(){
        int[] ejemplo1 = {0, 0, 3, 0, 0};
        int[] ejemplo2 = {5};
        
        Polinomio p1 = new Polinomio(ejemplo1);
        Polinomio p2 = new Polinomio();
        
        System.out.println(p1.grado()); //4
        System.out.println(p1.coeficiente(2));
        System.out.println(p1.coeficiente(8));
        System.out.println(p1.valor(1.0f));
        System.out.println(p1.toString());
        p1.coeficiente(3, 5);
       System.out.println(p1.coeficientes());
       
    }
}