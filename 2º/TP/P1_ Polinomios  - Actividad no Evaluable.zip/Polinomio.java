public class Polinomio{
    private int[] coef;
    
    public Polinomio() {
        this.coef = new int[1];
        this.coef[0] = 0;
    }
    
    public Polinomio(int[] vec) {
        this.coef = new int[vec.length];
        for (int i=0; i<vec.length; i++) {
            this.coef[i] = vec[i];
        }
    }
    
    public int grado(){
        for (int i=coef.length-1; i>0; i--){
            if (coef[i] != 0){
                return i;
            }
        }
        return 0;
    }
    
    public int coeficiente(int i){
        if ((i >= coef.length) || (i < 0)){
            return 0;
        }
        return coef[i];
    }
    
    public void coeficiente(int i, int v){
        if (i>=0){
            if (i>=coef.length && v != 0){
                int[] coef2 = new int[i+1];
                for (int j=0; j<coef.length; j++){
                    coef2[j] = coef[j];
                }
                coef2[i] = v;
                coef = coef2;
            }
            else{
                coef[i] = v;
            }
        }
    }
    
    public int[] coeficientes(){
        int[] vec = new int[grado()+1];
        for (int i=0; i<vec.length; i++){
            vec[i] = coef[i];
        }
        return vec;
    }
    
    @Override
    public String toString(){
        if(grado() == 0 && coef[0] == 0){
            return "0";
        }
        
        String strResult = "";
        for (int i=coef.length-1; i>= 0; i--){
            if (coef[i] != 0 ){
                
                if (!strResult.isEmpty() && coef[i] > 0){
                    strResult += "+";
                }
                
                if (i == 0){
                    strResult += coef[i];
                }else if(i == 1){
                    if (coef[i] == 1){
                        strResult +="x";
                    }else if (coef[i] == -1){
                        strResult += "-x";
                    }else{
                        strResult += coef[i] + "x";
                    }
                }else{
                    if (coef[i] == 1){
                        strResult += "x^" + i;
                    }else if (coef[i] == -1){
                        strResult += "-x^" + i;
                    }else{
                        strResult += coef[i] + "x^" + i;
                    }
                }
            }
        }
        return strResult;
    }
    
    public float valor(float n){
        float suma = 0.0f;
        for (int i=0; i<coef.length; i++){
            suma += coef[i] * Math.pow(n, i);
        }
        return suma;
    }
    
    public Polinomio suma(Polinomio otro){
        int maxLen = Math.max(coef.length, otro.coef.length);
        int[] newVec = new int[maxLen];
        for (int i=0; i<otro.coef.length; i++){
            newVec[i] = otro.coef[i];
        } 
        for (int i=0; i<coef.length; i++){
            newVec[i] += coef[i];
        }
        Polinomio result = new Polinomio(newVec);
        return result;
    }
    
    public Polinomio resta(Polinomio otro){
    int maxLen = Math.max(coef.length, otro.coef.length);
    int[] newVec = new int[maxLen];
    for (int i=0; i<coef.length; i++){
        newVec[i] = coef[i];
    } 
    for (int i=0; i<otro.coef.length; i++){
        newVec[i] -= otro.coef[i];
    }
    Polinomio result = new Polinomio(newVec);
    return result;
    }
}