def solve(input_list):
    """
    Calcula la suma de los valores de calibración de una lista de líneas.

    Cada línea puede contener dígitos numéricos y/o dígitos escritos en inglés:
    zero, one, two, three, four, five, six, seven, eight, nine.

    Para cada línea se debe formar un número de dos cifras con:
        - el primer dígito que aparece al recorrer la línea de izquierda a derecha;
        - el último dígito que aparece al recorrer la línea de izquierda a derecha.

    Las palabras pueden solaparse. Por ejemplo:
        - "twone" contiene "two" y "one", por tanto produce 21.
        - "oneight" contiene "one" y "eight", por tanto produce 18.

    Parámetros:
        input_list: lista de cadenas de texto, una por cada línea de entrada.

    Restricciones:
        - No leer datos por teclado dentro de esta función.
        - No imprimir resultados dentro de esta función.
        - Devolver un entero con la suma total.
    """
    numbers = {
        "one": "1", "two": "2", "three": "3", "four":"4", "five": "5",
        "six": "6", "seven": "7", "eight": "8", "nine": "9"
        }    
    
    total_sum = 0
    
    for line in input_list:
        first_dig = last_digit = ""
        for i in range(len(line)):
            if line[i].isdigit():
                first_dig += line[i]
                break
            else:
                for number, digit in numbers.items():
                    if line[i:].startswith(number):
                        first_dig += digit
                        break
            if first_dig:
                break
            
        for i in range(len(line)-1, -1, -1):
            if line[i].isdigit():
                last_digit += line[i]
                break
            else:
                for number, digit in numbers.items():
                    if line[i:].startswith(number):
                        last_digit += digit
                        break
            if last_digit:
                break
    
        if not first_dig:
            total_sum += 0
        else:
            total_sum += int(first_dig+last_digit)
    
    return total_sum

#Otra opción, ¿menos eficiente?
# for line in input_list:
#     aux = ""
#     for i in range(len(line)):
#         if line[i].isdigit():
#             aux += line[i]
#         else:
#             for number, digit in numbers.items():
#                 if line[i:].startswith(number):
#                     aux += digit
#     if not aux:
#         total_sum += 0
#     else:
#         total_sum += int(aux[0]+aux[len(aux)-1])

# return total_sum
        