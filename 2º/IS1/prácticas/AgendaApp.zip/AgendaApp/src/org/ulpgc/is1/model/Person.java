package org.ulpgc.is1.model;

public class Person extends Contact{
    private String firstname;
    private String lastname;

    public Person(String firstname, String lastname, String email, String telephone, String street, int number, int floor, String city) {
        this.firstname = firstname;
        this.lastname = lastname;
        setAddress( street, number, floor, city);
        setEmail(email);
        setTelephone(telephone);
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    @Override
    public String getName(){
        return firstname + lastname;
    }
}
