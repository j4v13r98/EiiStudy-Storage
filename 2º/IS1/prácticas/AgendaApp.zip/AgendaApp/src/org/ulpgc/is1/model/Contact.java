package org.ulpgc.is1.model;

public abstract class Contact {
    private String telephone;
    private String email;
    private Address address;

    public void setAddress(String street, int number, int floor, String city) {
        this.address = new Address(street, number, floor, city);
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelephone() {
        return telephone;
    }

    public String getEmail() {
        return email;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public abstract String getName();

    @Override
    public boolean equals(Object obj){
        if (this == obj){
            return true;
        }
        if ((!(obj instanceof Contact))){
            return false;
        }
        Contact other = (Contact) obj;
        if((this.telephone.equals(other.telephone) && (this.email.equals(other.email)))){
            return true;
        }
        return false;
    }
}
