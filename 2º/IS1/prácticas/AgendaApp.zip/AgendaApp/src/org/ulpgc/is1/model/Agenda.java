package org.ulpgc.is1.model;

import java.util.ArrayList;
import java.util.List;

public class Agenda {
    private List<Contact> contactList;
    private List<Group> groupList;

    public Agenda() {
        this.contactList = new ArrayList<>();
        this.groupList = new ArrayList<>();
    }

    public void addPerson(String firstName, String lastName, String telephone, String email, String street, int number, int floor, String city){
        if (!contactList.contains(new Person(firstName, lastName, telephone, email, street, number, floor, city))){
            contactList.add(new Person(firstName, lastName, telephone, email, street, number, floor, city));
        }
    }

    public void addCompany(String name, String description, String telephone, String email, String street, int number, int floor, String city){
        contactList.add(new Person(name, description, telephone, email, street, number, floor, city));
    }

    public void addGroup(String name){
        if (!groupList.contains(new Group(name))) {
            groupList.add(new Group(name));
        }
    }

    public List<Contact> getContactList(){
        return this.contactList;
    }

    public List<Group> getGroupList(){
        return this.groupList;
    }

    public void addContact2Group(Group group, Contact contact){
        group.addContact(contact);
    }
}
