package org.ulpgc.is1.control;

import org.ulpgc.is1.model.Agenda;
import org.ulpgc.is1.model.Contact;
import org.ulpgc.is1.model.Group;

import java.time.format.DateTimeFormatter;

public class Main {
    public static void main(String[] args) {
        Agenda agenda = new Agenda();

        agenda.addPerson("Juan", "Pérez", "600111222", "juan.perez@email.com", "Calle Mayor", 10, 1, "Las Palmas");
        agenda.addPerson("María", "García", "600333444", "maria.garcia@email.com", "Avenida Marítima", 25, 3, "Las Palmas");

        agenda.addGroup("trabajo");

        Group grupoTrabajo = agenda.getGroupList().get(0);
        Contact contactoJuan = agenda.getContactList().get(0);

        grupoTrabajo.addContact(contactoJuan);

        System.out.println("Número de contactos en la agenda: " + agenda.getContactList().size());

        agenda.addPerson("Juan", "Pérez", "600111222", "juan.perez@email.com", "Calle Mayor", 10, 1, "Las Palmas");

        System.out.println("Contactos en la agenda después de intentar duplicar: " + agenda.getContactList().size());

        System.out.println("Número de contactos en el grupo 'trabajo': " + grupoTrabajo.getMemberList().size());

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");

        String fechaFormateada = grupoTrabajo.getMemberList().get(0).getDate().format(formatter);

        System.out.println("Fecha en la que se agregó al grupo: " + fechaFormateada);

        grupoTrabajo.getMemberList().remove(0); // O grupoTrabajo.removeContact(0);

        System.out.println("Número de contactos en el grupo 'trabajo' tras borrar: " + grupoTrabajo.getMemberList().size());
    }
}