package org.ulpgc.is1.model;

import java.util.ArrayList;
import java.util.List;

public class Group{
    private final String name;
    private List<Member> memberList;


    public Group(String name) {
        this.memberList = new ArrayList<>();
        this.name = name;
    }

    public List<Member> getMemberList() {
        return memberList;
    }

    public void setMemberList(List<Member> memberList) {
        this.memberList = memberList;
    }

    public String getName() {
        return name;
    }

        public void addContact(Contact contact){
        memberList.add(new Member(contact));
    }

    public void removeContact(int index){
        memberList.remove(index);
    }

    @Override
    public boolean equals(Object obj){
        if (this == obj){
            return true;
        }
        if ((!(obj instanceof Group))){
            return false;
        }
        Group other = (Group) obj;
        return this.name.equals(other.name);
    }
}
