package org.ulpgc.is1;

import java.util.Scanner;

public class Main {
    static void main(String[] args) {
        Greeting firstGreeting = new Greeting();
        Scanner input = new Scanner(System.in);
        System.out.println("Introduce your name");
        String name = input.nextLine();
        firstGreeting.setName(name);
        firstGreeting.sayHello();
    }
}
