package org.ulpgc.is1;

public class Greeting {
    private String name;

    public Greeting(){
        this.name = "";
    }

    public void setName(String name){
        this.name = name;
    }

    public void sayHello(){
        System.out.println("Hello, " + this.name);
    }
}
